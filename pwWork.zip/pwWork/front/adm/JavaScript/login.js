let login = document.querySelector("#login");

login.addEventListener('click', ()=>{
    window.location.href = "../html/principal.html";
})