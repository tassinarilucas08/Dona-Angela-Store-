let register = document.querySelector("#register");

register.addEventListener('click', ()=>{
    window.location.href = "../html/principal.html";
})